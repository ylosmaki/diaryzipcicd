package fi.academy.diary_jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
/*@CrossOrigin(origins = "http://localhost:63342")*/
@CrossOrigin(origins="*") //this reference used for cloud services
public class TopicController {

    @Autowired
    TopicRepository topRep;

    //lists all topics
    @GetMapping("")
    public List<Topic> allTopics() {
        List<Topic> topics = new ArrayList<>();
        Iterable<Topic> result = topRep.findAll();
        result.iterator().forEachRemaining(topics::add);
        return topics;
    }

//automatically sets complete=false and creation date=today
    @PostMapping("")
    public void newTopic(@RequestBody Topic topic) {
//        topic.setComplete(false);
/*        Date today = (Date) Calendar.getInstance().getTime();
        topic.setCreationdate(today);*/
        topRep.save(topic);
    }

    //deletes topic by id
    @DeleteMapping("/{id}")
    public void deleteTopic(@PathVariable(name="id") Integer id) {
        Topic topic = topRep.findAllById(id);
        topRep.delete(topic);
    }

    //changes topic information
    @PutMapping("/{id}")
    public void changeSomething(@PathVariable(name="id") Integer id, @RequestBody Topic top) {
        Topic old = topRep.findAllById(id);
        old.setTitle(top.getTitle());
        old.setDescription(top.getDescription());
        old.setAdditionalsource(top.getAdditionalsource());
        old.setCreationdate(top.getCreationdate());
        old.setCompletiondate(top.getCompletiondate());
        old.setComplete(top.isComplete());
        old.setAlarm(top.getAlarm());
        old.setSetAlarm(top.isSetAlarm());
        topRep.save(old);
    }

}
