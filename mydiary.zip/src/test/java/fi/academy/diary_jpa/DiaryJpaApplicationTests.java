package fi.academy.diary_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiaryJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
